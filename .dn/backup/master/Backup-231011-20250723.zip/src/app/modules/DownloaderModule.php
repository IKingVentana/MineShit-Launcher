<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\System;


class DownloaderModule extends AbstractModule
{
    /**
     * Скачивание архива
     */
    static function downloadZip($url, $localPath, $onProgress = null) {
        fs::copy($url, $localPath);
        // Можно добавить onProgress если требуется (в цикле скачивания)
    }

    /**
     * Распаковка архива через PowerShell
     */
static function extractZip($zip, $dest) {
    $zip = str_replace('/', '\\', $zip);
    $dest = str_replace('/', '\\', $dest);

    // Создать папку если её нет
    if (!is_dir($dest)) fs::makeDir($dest);

    $cmd = [
        "powershell",
        "-Command",
        "Expand-Archive -Force -Path '$zip' -DestinationPath '$dest'"
    ];

    try {
        $proc = new \php\lang\Process($cmd);
        $proc->startAndWait();

        // Проверка
        $testFile = $dest . '\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe';
        if (!file_exists($testFile)) {
            file_put_contents('unpack_error.log', "Файл javaw.exe не найден после распаковки!\n", FILE_APPEND);
        }
    } catch (\Throwable $e) {
        file_put_contents('unpack_error.log', $e->getMessage(), FILE_APPEND);
        throw $e;
    }
}

    /**
     * Проверка, установлен ли клиент
     */
    static function isInstalled($appdata) {
        return is_dir($appdata . "\\.mineshit\\game")
            && is_file($appdata . "\\.mineshit\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }
}