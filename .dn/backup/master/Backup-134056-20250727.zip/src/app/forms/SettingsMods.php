<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\event\UXMouseEvent;

class SettingsMods extends AbstractForm
{
    public $onApply = null;
    public $modCheckboxes = [];

    public $modsList = [
        "DistantHorizon"   => "DistantHorizons-2.3.4-b-1.20.1-fabric-forge.jar",
        "VoiceChat"        => "voicechat-forge-1.20.1-2.5.35.jar",
        "EmojiType"        => "emoji-type-2.2.3+1.20.4-forge legacy.jar",
        "CameraOverhaul"   => "CameraOverhaul-v2.0.4-forge+mc[1.20.0-1.20.5].jar",
        "JEI"              => "jei-1.20.1-forge-15.20.0.108.jar",
        "XaerosWorldMap"   => "XaerosWorldMap_1.39.9_Forge_1.20.jar",
        "XaerosMinimap"    => "Xaeros_Minimap_25.2.6_Forge_1.20.jar"
    ];

    public $defaultMods = [
        "DistantHorizon"   => false,
        "VoiceChat"        => true,
        "EmojiType"        => true,
        "CameraOverhaul"   => false,
        "JEI"              => true,
        "XaerosWorldMap"   => true,
        "XaerosMinimap"    => true
    ];

    /**
     * @event form.show
     */
    function doFormShow()
    {
        // Путь к папке и файлу
        $appdata = getenv('APPDATA');
        $gameDir = $appdata . "\\.mineshit\\game";
        $configFile = $gameDir . "\\mods_config.json";
        $modsConfig = $this->defaultMods;

        // Читаем настройки из файла если он есть
        if (file_exists($configFile)) {
            $fileData = json_decode(file_get_contents($configFile), true);
            if (is_array($fileData)) {
                $modsConfig = array_merge($modsConfig, $fileData);
            }
        }

        // Устанавливаем состояния чекбоксов
        foreach ($this->modsList as $modId => $filename) {
            if (isset($this->{$modId})) {
                $this->{$modId}->selected = !!$modsConfig[$modId];
                $this->modCheckboxes[$modId] = $this->{$modId};
            }
        }
    }

    /**
     * @event ApplyModsButton.click-Left
     */
    function doApplyModsButtonClickLeft(\php\gui\event\UXMouseEvent $e = null)
    {
        // Список всех ID модов и соответствующих чекбоксов
        $modIds = [
            "DistantHorizon",
            "VoiceChat",
            "EmojiType",
            "CameraOverhaul",
            "JEI",
            "XaerosWorldMap",
            "XaerosMinimap"
        ];
    
        $selectedMods = [];
    
        foreach ($modIds as $modId) {
            // Проверяем, существует ли чекбокс и что это именно UXCheckBox
            if (isset($this->{$modId}) && $this->{$modId} instanceof \php\gui\UXCheckBox) {
                $selectedMods[$modId] = (bool)$this->{$modId}->selected;
            } else {
                // Если по каким-то причинам чекбокс не найден, пишем false по умолчанию
                $selectedMods[$modId] = false;
            }
        }
    
        // Сохраняем в mods_config.json
        $appdata = getenv('APPDATA');
        $gameDir = $appdata . "\\.mineshit\\game";
        $configFile = $gameDir . "\\mods_config.json";
    
        if (!is_dir($gameDir)) mkdir($gameDir, 0777, true);
        file_put_contents($configFile, json_encode($selectedMods, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
        // Можно скрыть настройки после применения (если это модальное окно или Fragment)
        if (isset($this->ModSettingsFragment)) {
            $this->ModSettingsFragment->visible = false;
        }
        // Можно добавить уведомление для пользователя:
        // alert("Настройки модов применены!");
    }
}
