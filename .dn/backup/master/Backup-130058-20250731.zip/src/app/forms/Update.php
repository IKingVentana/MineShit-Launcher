<?php
namespace app\forms;

use std, gui, framework, app;


class Update extends AbstractForm
{
    /**
     * @event ActiveUpdateButton.click
     */
    function doActiveUpdateButtonClick($e = null)
    {
        // Путь до Updater.jar — должен лежать рядом с exe
        $version = \app\forms\MainForm::VERSION; // или как у тебя объявлена версия
        $exeName = "MineShit Launcher.exe"; // обязательно с правильным именем!

        // Запуск Updater.jar с нужными аргументами
        execute("java -jar Updater.jar {$version} {$exeName}");
        
        // Завершаем лаунчер (его закроет Updater)
        app()->shutdown();
    }
}
