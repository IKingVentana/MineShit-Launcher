<?php
namespace app\forms;

use std, gui, framework, app;
use Throwable;
use std;
use Exception;
use gui;
use php\gui\UXNode;
use php\gui\framework\AbstractForm;
use php\io\IOException;
use php\lang\ProcessBuilder;
use php\lang\System;
use php\util\Regex;
use php\gui\event\UXWindowEvent;
use php\gui\event\UXMouseEvent;
use app\modules\ControlFinder; // Подключаем модуль
use php\io\File;
use php\lang\ProcessBuilder;
use php\io\Stream;
use java\io\BufferedReader;
use java\io\InputStreamReader;

class MainFormLoginned extends AbstractForm
{

    private $modSettingsVisible = false;

/**
 * @event StartButton.click-Left
 */
function doStartButtonClickLeft(UXMouseEvent $e = null)
{
	$login - $this->LauncherLoginField->text;
	$_LAUNCHER_PATH = "C:/Users/Development/AppData/Roaming/.zaklauncher";

	$_JAVA_PATHS_LAUNCHER_PATH . "/openjdk";
	$_MINECRAFT_PATH = $_LAUNCHER_PATH . "/minecraft";
	$_VERSIONS_PATH = $_LAUNCHER_PATH . "/minecraft/versions";

	$command = "\"$_JAVA_PATH/jdk-17.0.7+7-jre/bin/java.exe\" -XX:-UseAdaptiveSizePolicy -XX:-OmitStackTraceInFastThrow -Dfml.ignorePatchDiscrepancies=true -Dfml.ignoreInvalidMinecraftCertificates=true -Djava.library.path=\"$_MINECRAFT_PATH\" -Xmx4096M -Xms1G -XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump -Dminecraft.api.auth.host=http://127.0.0.1 -Dminecraft.api.account.host=http://127.0.0.1 -Dminecraft.api.session.host=http://127.0.0.1 -Dminecraft.api.services.host=http://127.0.0.1 -cp \"$_MINECRAFT_PATH/libraries/com/github/oshi/oshi-core/6.2.2/oshi-core-6.2.2.jar\";\"$_MINECRAFT_PATH/libraries/com/google/code/gson/gson/2.10/gson-2.10.jar\";\"$_MINECRAFT_PATH/libraries/com/google/guava/failureaccess/1.0.1/failureaccess-1.0.1.jar\";\"$_MINECRAFT_PATH/libraries/com/google/guava/guava/31.1-jre/guava-31.1-jre.jar\";\"$_MINECRAFT_PATH/libraries/com/ibm/icu/icu4j/71.1/icu4j-71.1.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/authlib/4.0.43/authlib-4.0.43.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/blocklist/1.0.10/blocklist-1.0.10.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/brigadier/1.1.8/brigadier-1.1.8.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/datafixerupper/6.0.8/datafixerupper-6.0.8.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/logging/1.1.1/logging-1.1.1.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/patchy/2.2.10/patchy-2.2.10.jar\";\"$_MINECRAFT_PATH/libraries/com/mojang/text2speech/1.17.9/text2speech-1.17.9.jar\";\"$_MINECRAFT_PATH/libraries/commons-codec/commons-codec/1.15/commons-codec-1.15.jar\";\"$_MINECRAFT_PATH/libraries/commons-io/commons-io/2.11.0/commons-io-2.11.0.jar\";\"$_MINECRAFT_PATH/libraries/commons-logging/commons-logging/1.2/commons-logging-1.2.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-buffer/4.1.82.Final/netty-buffer-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-codec/4.1.82.Final/netty-codec-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-common/4.1.82.Final/netty-common-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-handler/4.1.82.Final/netty-handler-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-resolver/4.1.82.Final/netty-resolver-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-transport-classes-epoll/4.1.82.Final/netty-transport-classes-epoll-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-transport-native-unix-common/4.1.82.Final/netty-transport-native-unix-common-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/io/netty/netty-transport/4.1.82.Final/netty-transport-4.1.82.Final.jar\";\"$_MINECRAFT_PATH/libraries/it/unimi/dsi/fastutil/8.5.9/fastutil-8.5.9.jar\";\"$_MINECRAFT_PATH/libraries/net/java/dev/jna/jna-platform/5.12.1/jna-platform-5.12.1.jar\";\"$_MINECRAFT_PATH/libraries/net/java/dev/jna/jna/5.12.1/jna-5.12.1.jar\";\"$_MINECRAFT_PATH/libraries/net/sf/jopt-simple/jopt-simple/5.0.4/jopt-simple-5.0.4.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/commons/commons-compress/1.21/commons-compress-1.21.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/commons/commons-lang3/3.12.0/commons-lang3-3.12.0.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/httpcomponents/httpclient/4.5.13/httpclient-4.5.13.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/httpcomponents/httpcore/4.4.15/httpcore-4.4.15.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/logging/log4j/log4j-api/2.19.0/log4j-api-2.19.0.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/logging/log4j/log4j-core/2.19.0/log4j-core-2.19.0.jar\";\"$_MINECRAFT_PATH/libraries/org/apache/logging/log4j/log4j-slf4j2-impl/2.19.0/log4j-slf4j2-impl-2.19.0.jar\";\"$_MINECRAFT_PATH/libraries/org/joml/joml/1.10.5/joml-1.10.5.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-glfw/3.3.1/lwjgl-glfw-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-glfw/3.3.1/lwjgl-glfw-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-glfw/3.3.1/lwjgl-glfw-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-glfw/3.3.1/lwjgl-glfw-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-jemalloc/3.3.1/lwjgl-jemalloc-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-jemalloc/3.3.1/lwjgl-jemalloc-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-jemalloc/3.3.1/lwjgl-jemalloc-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-jemalloc/3.3.1/lwjgl-jemalloc-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-openal/3.3.1/lwjgl-openal-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-openal/3.3.1/lwjgl-openal-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-openal/3.3.1/lwjgl-openal-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-openal/3.3.1/lwjgl-openal-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-opengl/3.3.1/lwjgl-opengl-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-opengl/3.3.1/lwjgl-opengl-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-opengl/3.3.1/lwjgl-opengl-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-opengl/3.3.1/lwjgl-opengl-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-stb/3.3.1/lwjgl-stb-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-stb/3.3.1/lwjgl-stb-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-stb/3.3.1/lwjgl-stb-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-stb/3.3.1/lwjgl-stb-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-tinyfd/3.3.1/lwjgl-tinyfd-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-tinyfd/3.3.1/lwjgl-tinyfd-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-tinyfd/3.3.1/lwjgl-tinyfd-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl-tinyfd/3.3.1/lwjgl-tinyfd-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-windows-arm64.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-windows-x86.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-windows.jar\";\"$_MINECRAFT_PATH/libraries/org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar\";\"$_MINECRAFT_PATH/libraries/org/slf4j/slf4j-api/2.0.1/slf4j-api-2.0.1.jar\";\"$_VERSIONS_PATH/1.20.1/1.20.1.jar\" net.minecraft.client.main.Main --username $login --version 1.20.1 --gameDir \"$_VERSIONS_PATH/1.20.1\" --assetsDir \"$_MINECRAFT_PATH/assets\" --assetIndex 1.20.1 --uuid f349df47-0efc-31ec-aa56-ac549eb5fbe8 --accessToken f349df47-0efc-31ec-aa56-ac549eb5fbe8 --clientId f349df47-0efc-31ec-aa56-ac549eb5fbe8 --xuid f349df47-0efc-31ec-aa56-ac549eb5fbe8 --userType mojang --versionType release";
        execute($command);
}
    /**
     * @event ModSettingsButton.click-Left
     */
    function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
    {
        $this->modSettingsVisible = !$this->modSettingsVisible;
        $this->ModSettingsFragment->visible = $this->modSettingsVisible;

        if ($this->modSettingsVisible) {
            $this->ModSettingsButton->text = "Принять настройки";
            $this->ModSettingsButton->style = "-fx-background-color: #FFB800;";
        } else {
            $this->ModSettingsButton->text = "Настройки модов";
            $this->ModSettingsButton->style = "-fx-background-color: #FFFFFF;";
            $this->saveModSettings(); // вызываем сохранение
        }
    }

    /**
     * @event LeaveAccountButton.click-Left 
     */
    function doLeaveAccountButtonClickLeft(UXMouseEvent $e = null)
    {
        // Логика выхода из аккаунта
    }

    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть Discord ссылку или другое действие
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть Telegram ссылку или другое действие
    }

    /**
     * @event DonateButton.click-Left 
     */
    function doDonateButtonClickLeft(UXMouseEvent $e = null)
    {
        // Обработка пожертвований
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть папку с игрой или другое действие
    }

    /**
     * @event SettingsButton.click-Left 
     */
    function doSettingsButtonClickLeft(UXMouseEvent $e = null)
    {
        $form = app()->getForm('Settings');
        $form->setPreviousForm('MainFormLoginned'); // или 'MainForm' в другом случае
        $form->show();
        $this->hide();
    }


    /**
     * Установить ник игрока в поле логина
     */
    function setPlayerName(string $login)
    {
        if (isset($this->LauncherLoginField)) {
            $this->LauncherLoginField->text = $login;
            $this->LauncherLoginField->editable = false;
        }
    }
    
}
