<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{







    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ModSettingsButton.click-Left 
     */
    function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event LoginButton.click-Left 
     */
    function doLoginButtonClickLeft(UXMouseEvent $e = null)
    {    
                $login = $form->LoginField->text;
        $password = $form->PasswordField->text;
        
        Http::post("https://mscreate-data.ru/auth.php", [
            'login' => $login,
            'password' => $password
        ])->then(function($response) use ($form) {
            $json = json_decode($response->body());
            if ($json->status == "success") {
                $form->ConsoleLabel->text = "✅ Успешный вход!";
                // Тут можно переключить на профиль и включить кнопку СТАРТ
            } else {
                $form->ConsoleLabel->text = "❌ Неверный логин или пароль (error: 2)";
            }
        });
    }

    /**
     * @event SettingsButton.click-Left 
     */
    function doSettingsButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }






}
