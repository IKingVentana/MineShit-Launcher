<?php
namespace app\forms;

use std, gui, framework, app;


class Settings extends AbstractForm
{

    /**
     * @event ExitButton.click-Left 
     */
    function doExitButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
