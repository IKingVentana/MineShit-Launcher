<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\System;
use php\compress\ZipFile;

class DownloaderModule extends AbstractModule
{
    /**
     * Скачивание архива
     */
    static function downloadZip($url, $localPath, $onProgress = null) {
        fs::copy($url, $localPath);
        // Можно добавить onProgress если требуется (в цикле скачивания)
    }

    /**
     * Распаковка архива через PowerShell
     */
static function extractZip($zip, $dest) {
    $zipFile = new ZipFile($zip);
    $zipFile->unpack($dest);
    fs::delete($zip);
}

    /**
     * Проверка, установлен ли клиент
     */
    static function isInstalled($appdata) {
        return is_dir($appdata . "\\.mineshit\\game")
            && is_file($appdata . "\\.mineshit\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }
}