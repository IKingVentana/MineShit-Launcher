<?php
namespace app\forms;

use std, gui, framework, app;


class Settings extends AbstractForm
{

private $previousForm = null;
private $previousX = 0;
private $previousY = 0;


public function setPreviousForm($formName)
{
    $this->previousForm = $formName;

    $form = app()->getForm($formName);
    $this->previousX = $form->x;
    $this->previousY = $form->y;

    // Ставим настройки в то же место
    $this->x = $this->previousX;
    $this->y = $this->previousY;
}


/**
 * @event ExitButton.click-Left
 */
function doExitButtonClickLeft(UXMouseEvent $e = null)
{
    if ($this->previousForm) {
        $form = app()->getForm($this->previousForm);
        $form->show();
    }
    $this->hide();
}

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }
    
    
    /**
     * ОПЕРАТИВНАЯ ПАМЯТЬ -----------------------------------------------------------------------------------------------------------------------------------------------
     */
     
     
    /**
     * RAM-кнопки — список ID, можно редактировать
     */
    private $ramButtons = ['RamButton3', 'RamButton4', 'RamButton6', 'RamButton8', 'RamButton10'];
    private $selectedRam = '4 GB'; // Значение по умолчанию

    /**
     * Обработчик кликов по кнопкам RAM
     */
    function handleRamButtonClick(string $id, string $label)
    {
        foreach ($this->ramButtons as $btnId) {
            $this->{$btnId}->classes->remove('ram-active');
            $this->{$btnId}->classes->add('ram-inactive');
        }
    
        $this->selectedRam = $label;
    // Сохраняем в файл (например, число ГБ)
        file_put_contents(getenv('APPDATA') . "/.mineshit-create/user_settings.txt", $label);
    }
    
    /**
     * @event RamButton3.click-Left
     */
    function doRamButton3ClickLeft(UXMouseEvent $e = null)
    {
        $this->handleRamButtonClick('RamButton3', '3 GB');
    }
    
    /**
     * @event RamButton4.click-Left
     */
    function doRamButton4ClickLeft(UXMouseEvent $e = null)
    {
        $this->handleRamButtonClick('RamButton4', '4 GB');
    }
    
    /**
     * @event RamButton6.click-Left
     */
    function doRamButton6ClickLeft(UXMouseEvent $e = null)
    {
        $this->handleRamButtonClick('RamButton6', '6 GB');
    }
    
    /**
     * @event RamButton8.click-Left
     */
    function doRamButton8ClickLeft(UXMouseEvent $e = null)
    {
        $this->handleRamButtonClick('RamButton8', '8 GB');
    }
    
    /**
     * @event RamButton10.click-Left
     */
    function doRamButton10ClickLeft(UXMouseEvent $e = null)
    {
        $this->handleRamButtonClick('RamButton10', '10 GB');
    }

    /**
     * @event InfoButton.click-Left 
     */
    function doInfoButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event UpdateButton.click-Left 
     */
    function doUpdateButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event DeleteLauncherButton.click-Left 
     */
    function doDeleteLauncherButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event DeleteClientButton.click-Left 
     */
    function doDeleteClientButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }
        
    
    /**
     * ДРУГОЕ -----------------------------------------------------------------------------------------------------------------------------------------------
     */
     
     
}
