<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{







    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }





}
