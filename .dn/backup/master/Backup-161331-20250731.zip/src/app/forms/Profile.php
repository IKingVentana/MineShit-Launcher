<?php
namespace app\forms;

use std, gui, framework, app;


class Profile extends AbstractForm
{

    private $previousForm = null;
    private $previousX = 0;
    private $previousY = 0;
    
    
    public function setPreviousForm($formName)
    {
        $this->previousForm = $formName;
    
        $form = app()->getForm($formName);
        $this->previousX = $form->x;
        $this->previousY = $form->y;
    
        // Ставим настройки в то же место
        $this->x = $this->previousX;
        $this->y = $this->previousY;
    }
    
    /**
     * @event ExitButton.click-Left
     */
    function doExitButtonClickLeft(UXMouseEvent $e = null)
    {
        if ($this->previousForm) {
            $form = app()->getForm($this->previousForm);
            $form->show();
        }
        $this->hide();
    }

}
