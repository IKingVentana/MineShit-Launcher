<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\System;


class DownloaderModule extends AbstractModule
{
    /**
     * Скачивание архива
     */
    static function downloadZip($url, $localPath, $onProgress = null) {
        fs::copy($url, $localPath);
        // Можно добавить onProgress если требуется (в цикле скачивания)
    }

    /**
     * Распаковка архива через PowerShell
     */
static function extractZip($zip, $dest) {
    $zip = str_replace('/', '\\', $zip);
    $dest = str_replace('/', '\\', $dest);

    $cmd = [
        "powershell",
        "-Command",
        "Expand-Archive -Force -Path '$zip' -DestinationPath '$dest'"
    ];

    try {
        $proc = new \php\lang\Process($cmd);
        $proc->startAndWait();
    } catch (\Throwable $e) {
        // Можно сделать вывод ошибки в лог
        throw $e;
    }
}

    /**
     * Проверка, установлен ли клиент
     */
    static function isInstalled($appdata) {
        return is_dir($appdata . "\\.mineshit-create\\game")
            && is_file($appdata . "\\.mineshit-create\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }
}