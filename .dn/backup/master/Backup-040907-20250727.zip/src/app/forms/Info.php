<?php
namespace app\forms;

use httpclient;
use Exception;
use std, gui, framework, app;

class Info extends AbstractForm
{

/**
 * @event show
 */
function doShow(\php\gui\event\UXEvent $e = null)
{
    try {
        $client = new HttpClient();
        $version = $client->get("https://mscreate-data.ru/version.php")->body();
        $this->ServerVersion->text = "Сервер: " . trim($version);
    } catch (\Exception $ex) {
        $this->ServerVersion->text = "Сервер: ошибка загрузки";
    }
    
        // Версия лаунчера (берётся из Project → Settings → Version)
    $launcherVersion = app()->version;
    $this->LauncherVersion->text = "Лаунчер: " . $launcherVersion;
}
        
    /**
     * @event ResizeButton.click-Left 
     */
    function doResizeButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event DonateButton.click-Left 
     */
    function doDonateButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ReportButton.click-Left 
     */
    function doReportButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event FAQButton.click-Left 
     */
    function doFAQButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
