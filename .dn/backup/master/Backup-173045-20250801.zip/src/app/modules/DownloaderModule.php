<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\System;
use php\compress\ZipFile;

class DownloaderModule extends AbstractModule
{
    /**
     * Скачивание архива
     */
    static function downloadZip($url, $localPath, $onProgress = null) {
        // СТАРЫЙ ВАРИАНТ:
        // fs::copy($url, $localPath);
    
        // НОВЫЙ ВАРИАНТ:
        $in = @fopen($url, "rb");
        if ($in === false) {
            throw new \Exception("Не удалось открыть $url для чтения");
        }
        $out = @fopen($localPath, "wb");
        if ($out === false) {
            fclose($in);
            throw new \Exception("Не удалось открыть $localPath для записи");
        }
        $bufSize = 1024 * 1024; // 1 МБ
        $downloaded = 0;
        while (!feof($in)) {
            $buf = fread($in, $bufSize);
            fwrite($out, $buf);
            $downloaded += strlen($buf);
            if ($onProgress) $onProgress($downloaded);
        }
        fclose($in);
        fclose($out);
    }

    /**
     * Распаковка архива через PowerShell
     */
static function extractZip($zip, $dest) {
    $zipFile = new ZipFile($zip);
    $zipFile->unpack($dest);
    fs::delete($zip);
}

    /**
     * Проверка, установлен ли клиент
     */
    static function isInstalled($appdata) {
        return is_dir($appdata . "\\.mineshit\\game")
            && is_file($appdata . "\\.mineshit\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }
}