<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\event\UXMouseEvent;
use php\gui\UXCheckbox;
use php\gui\UXForm;

class SettingsMods extends AbstractForm
{
    public $onApply = null;
    public $modCheckboxes = [];

    // Список модов и их названия для пользователя и для файла на сервере
    public $modsList = [
        "Distant Horizon"   => "DistantHorizons-2.3.4-b-1.20.1-fabric-forge.jar",
        "Voice Chat"        => "voicechat-forge-1.20.1-2.5.35.jar",
        "Emoji Type"        => "emoji-type-2.2.3+1.20.4-forge legacy.jar",
        "Camera Overhaul"   => "CameraOverhaul-v2.0.4-forge+mc[1.20.0-1.20.5].jar",
        "JEI"               => "jei-1.20.1-forge-15.20.0.108.jar",
        "XaerosWorldMap"    => "[CLIENT] XaerosWorldMap_1.39.9_Forge_1.20.jar",
        "Xaeros Minimap"    => "[CLIENT] Xaeros_Minimap_25.2.6_Forge_1.20.jar"
    ];

    public $defaultMods = [
        "VoiceChat"      => true,
        "EmojiType"      => true,
        "JEI"             => true,
        "XaerosWorldMap"  => true,
        "XaerosMinimap"  => true,
        "DistantHorizon" => false,
        "CameraOverhaul" => false
    ];

    /**
     * @event form.show
     */
    function doFormShow()
    {
        // Чтение состояния чекбоксов из конфига
        $configFile = app()->storagePath . "/mods_config.json";
        $modsConfig = $this->defaultMods;

        if (file_exists($configFile)) {
            $modsConfig = array_merge($modsConfig, json_decode(file_get_contents($configFile), true));
        }

        // Проставляем состояния чекбоксов
        foreach ($this->modsList as $modName => $filename) {
            if (isset($this->{$modName . "Checkbox"})) {
                $this->{$modName . "Checkbox"}->selected = !!$modsConfig[$modName];
                $this->modCheckboxes[$modName] = $this->{$modName . "Checkbox"};
            }
        }
    }

    /**
     * @event ApplyModsButton.click-Left
     */
    function doApplyModsButtonClickLeft(UXMouseEvent $e = null)
    {
        $selectedMods = [];
        foreach ($this->modCheckboxes as $modName => $checkbox) {
            $selectedMods[$modName] = $checkbox->selected;
        }

        // Сохраняем в файл
        file_put_contents(app()->storagePath . "/mods_config.json", json_encode($selectedMods, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        // Прячем фрагмент
        $this->hide();

        // Колбек
        if (is_callable($this->onApply)) {
            call_user_func($this->onApply, $selectedMods);
        }
    }
}
