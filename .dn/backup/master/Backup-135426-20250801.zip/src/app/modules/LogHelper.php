<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;

class LogHelper extends AbstractModule
{
    /** @var string|null */
    static $logFile = null;

    /**
     * Записать сообщение в лог.
     * @param string $msg
     */
    static function log($msg)
    {
        try {
            // Получаем путь к лог-файлу
            if (self::$logFile === null) {
                $logDir = getenv('APPDATA') . '\\.mineshit\\logs\\';
                if (!is_dir($logDir)) {
                    // Создаём папку для логов (если её нет)
                    mkdir($logDir, 0777, true);
                }
                self::$logFile = $logDir . 'launcher_' . date('Y-m-d') . '.log';
                // Если файл только что создан — добавляем BOM для корректного отображения UTF-8 в Windows
                if (!file_exists(self::$logFile)) {
                    file_put_contents(self::$logFile, "\xEF\xBB\xBF");
                }
            }

            $time = date('Y-m-d H:i:s');
            $msgLine = "[$time] $msg\n";

            // Записываем строку в лог
            file_put_contents(self::$logFile, $msgLine, FILE_APPEND | LOCK_EX);

        } catch (\Throwable $e) {
            // В случае ошибки логирования (почти никогда) — молча пропускаем, чтобы не крашить программу
        }
    }
}