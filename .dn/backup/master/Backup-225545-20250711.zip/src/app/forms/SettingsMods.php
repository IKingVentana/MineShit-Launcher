<?php
namespace app\forms;

use std, gui, framework, app;


class SettingsMods extends AbstractForm
{

    /**
     * @event mouseExit 
     */
    function doMouseExit(UXMouseEvent $e = null)
    {    
        
    }

}
