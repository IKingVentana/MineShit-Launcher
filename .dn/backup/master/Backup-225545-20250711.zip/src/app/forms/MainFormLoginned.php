<?php
namespace app\forms;

use std, gui, framework, app;
use php\io\File;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent;

class MainFormLoginned extends AbstractForm
{
    public $currentUser = null;

    /**
     * @event form.show
     */
    function doFormShow() {
        // При открытии формы загружаем ник из файла
        $file = new \php\io\File("user.txt");
        if ($file->exists()) {
            $stream = new \php\io\FileStream($file, \php\io\StreamMode::READ);
            $this->currentUser = trim($stream->readLine());
            $stream->close();
        }
        // Показываем ник пользователя в интерфейсе, например:
        $this->UserNameLabel->text = $this->currentUser;
    }

    /**
     * @event LogoutButton.click-Left
     */
    function doLogoutButtonClickLeft(UXMouseEvent $e = null) {
        // Удаляем файл с сохранением
        $file = new \php\io\File("user.txt");
        if ($file->exists()) $file->delete();

        // Закрываем эту форму и показываем форму входа
        $this->app->showForm('MainForm');
        $this->hide();
    }


    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ModSettingsButton.click-Left 
     */
    function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ProfileButton.click-Left 
     */
    function doProfileButtonClickLeft(UXMouseEvent $e = null)
    {    
        
        $login = LauncherLoginField->; // если ID поля логина — LoginField
        $password = LauncherPasswordField->; // если ты назвал поле именно так
        
        ConsoleLabel->text = "⏳ Проверка...";
        
        http::post("https://mscreate-data.ru/auth.php", [
            "login" => $login,
            "password" => $password
        ])->then(function($response) {
            $json = json_decode($response->body());
        
            if ($json->status === "ok") {
                ConsoleLabel->text = "✅ Успешный вход!";
                // тут можешь, например, включить кнопку СТАРТ
            } else {
                ConsoleLabel->text = "❌ Неверный логин или пароль";
            }
        })->catch(function($e) {
            ConsoleLabel->text = "⚠ Ошибка подключения к серверу";
        });
    }

    /**
     * @event SettingsButton.click-Left 
     */
    function doSettingsButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ConsoleLabel.construct 
     */
    function doConsoleLabelConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event LauncherLoginField.construct 
     */
    function doLauncherLoginFieldConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event DonateButton.click-Left 
     */
    function doDonateButtonClickLeft(UXMouseEvent $e = null)
    {
        
        $login = LauncherLoginField->; // если ID поля логина — LoginField
        $password = LauncherPasswordField->; // если ты назвал поле именно так
        
        ConsoleLabel->text = "⏳ Проверка...";
        
        http::post("https://mscreate-data.ru/auth.php", [
            "login" => $login,
            "password" => $password
        ])->then(function($response) {
            $json = json_decode($response->body());
        
            if ($json->status === "ok") {
                ConsoleLabel->text = "✅ Успешный вход!";
                // тут можешь, например, включить кнопку СТАРТ
            } else {
                ConsoleLabel->text = "❌ Неверный логин или пароль";
            }
        })->catch(function($e) {
            ConsoleLabel->text = "⚠ Ошибка подключения к серверу";
        });
    }

    /**
     * @event LeaveAccountButton.click-Left 
     */
    function doLeaveAccountButtonClickLeft(UXMouseEvent $e = null)
    {
        
        $login = LauncherLoginField->; // если ID поля логина — LoginField
        $password = LauncherPasswordField->; // если ты назвал поле именно так
        
        ConsoleLabel->text = "⏳ Проверка...";
        
        http::post("https://mscreate-data.ru/auth.php", [
            "login" => $login,
            "password" => $password
        ])->then(function($response) {
            $json = json_decode($response->body());
        
            if ($json->status === "ok") {
                ConsoleLabel->text = "✅ Успешный вход!";
                // тут можешь, например, включить кнопку СТАРТ
            } else {
                ConsoleLabel->text = "❌ Неверный логин или пароль";
            }
        })->catch(function($e) {
            ConsoleLabel->text = "⚠ Ошибка подключения к серверу";
        });
    }









}
