<?php
namespace app\forms;

use httpclient;
use std, gui, framework, app;
use php\io\File;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent;
use httpclient\HttpClient;

class MainForm extends AbstractForm
{
    // Путь к файлу для сохранения логина
    private $userFile = "user.txt";

    /**
     * @event form.show
     */
    function doFormShow()
    {
        // При открытии формы проверяем, сохранён ли логин
        if (File::exists($this->userFile)) {
            $savedLogin = File::getContent($this->userFile);
            if (strlen($savedLogin) > 0) {
                $this->openLoggedInForm($savedLogin);
            }
        }
    }

    /**
     * @event LoginButton.click-Left
     */
    function doLoginButtonClickLeft(UXMouseEvent $e = null)
    {
        $login = $this->LauncherLoginField->text;
        $password = $this->LauncherPasswordField->text;

        $this->ConsoleLabel->text = "⏳ Проверка...";

        $client = new HttpClient();

        $client->post("https://mscreate-data.ru/auth.php", [
            "login" => $login,
            "password" => $password
        ])->then(function($response) use ($login) {
            $json = json_decode($response->body());

            if ($json && $json->status === "ok") {
                $this->ConsoleLabel->text = "✅ Успешный вход!";

                // Сохраняем логин в файл
                File::putContent($this->userFile, $login);

                // Открываем форму залогиненного пользователя
                $this->openLoggedInForm($login);

            } else {
                $this->ConsoleLabel->text = "❌ Неверный логин или пароль";
            }
        })->catch(function($e) {
            $this->ConsoleLabel->text = "⚠ Ошибка подключения: " . $e->getMessage();
        });
    }

    /**
     * Открыть форму залогиненного пользователя
     * и закрыть текущую форму
     */
    private function openLoggedInForm(string $login)
    {
        // Передать ник в форму MainFormLoginned
        $form = app()->getForm('MainFormLoginned');
        if ($form) {
            $form->setPlayerName($login); // Допустим, в MainFormLoginned есть такой метод
            $form->show();
            $this->hide();
        } else {
            $this->ConsoleLabel->text = "⚠ Ошибка: форма MainFormLoginned не найдена";
        }
    }

    /**
     * @event SettingsButton.click-Left
     */
    function doSettingsButtonClickLeft(UXMouseEvent $e = null)
    {
        // Если пользователь залогинен - открыть настройки с формы MainFormLoginned
        $form = app()->getForm('MainFormLoginned');
        if ($form && $form->isVisible()) {
            $form->openSettings();
        } else {
            // Иначе открыть настройки текущей формы
            // Твой код открытия настроек для незалогиненного пользователя
        }
    }
    
    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event ModSettingsButton.click-Left 
     */
    function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event LauncherLoginField.construct 
     */
    function doLauncherLoginFieldConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event LauncherPasswordField.construct 
     */
    function doLauncherPasswordFieldConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event LauncherPasswordField.globalKeyDown-Space 
     */
    function doLauncherPasswordFieldGlobalKeyDownSpace(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event StartButton.click-Left 
     */
    function doStartButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }







}
