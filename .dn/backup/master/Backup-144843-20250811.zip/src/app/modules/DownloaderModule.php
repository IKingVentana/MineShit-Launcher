<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\Thread;
use php\compress\ZipFile;

class DownloaderModule extends AbstractModule
{
    /** Безопасный лог: не используем class_exists, не даём упасть */
    private static function safeLog(string $msg): void
    {
        try {
            \app\modules\LogHelper::log($msg);
        } catch (\Throwable $e) {
            // игнор
        }
    }

    /**
     * Универсальная потоковая загрузка большого файла с ретраями и .part
     */
    public static function downloadFile(string $url, string $dest, string $label = '', int $retries = 3, $onProgress = null): bool
    {
        $tmp = $dest . '.part';

        for ($attempt = 1; $attempt <= $retries; $attempt++) {
            try {
                if (file_exists($tmp)) @unlink($tmp);

                // fs::copy в JPHP — потоковая копия, без удержания всего файла в памяти
                fs::copy($url, $tmp);

                $size = file_exists($tmp) ? filesize($tmp) : 0;
                if ($size <= 0) {
                    throw new \Exception("Пустой файл после загрузки [$label]");
                }

                if (file_exists($dest)) @unlink($dest);
                @rename($tmp, $dest);

                self::safeLog("✅ downloadFile OK [$label], {$size} байт");
                return true;
            } catch (\Throwable $e) {
                self::safeLog("❌ downloadFile ERR [$label] попытка $attempt: " . $e->getMessage());
                @unlink($tmp);
                Thread::sleep(1000 * $attempt); // бэкофф
            }
        }
        return false;
    }

    /** Обёртка для ZIP */
    public static function downloadZip(string $url, string $localPath, $onProgress = null): bool
    {
        return self::downloadFile($url, $localPath, 'zip', 3, $onProgress);
    }

    /** Распаковка архива */
    public static function extractZip(string $zip, string $dest): void
    {
        $zipFile = new ZipFile($zip);
        $zipFile->unpack($dest);
        fs::delete($zip);
    }

    /** Проверка, установлен ли клиент */
    public static function isInstalled(string $appdata): bool
    {
        return is_dir($appdata . "\\.mineshit\\game")
            && is_file($appdata . "\\.mineshit\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }

    /**
     * Удаляет все .jar в mods/, которых нет в белом списке (имена файлов).
     * БЕЗОПАСНО: не падает, если путь пустой/нет папки/ошибка сканирования.
     */
    public static function cleanModsDirectory(?string $modsDir, array $allowList): void
    {
        try {
            if (!$modsDir || !is_string($modsDir)) {
                self::safeLog("⚠ cleanModsDirectory: пустой путь к каталогу модов");
                return;
            }
            if (!fs::isDir($modsDir)) {
                self::safeLog("⚠ cleanModsDirectory: нет папки $modsDir — пропускаю");
                return;
            }
    
            $modsDir = rtrim($modsDir, "\\/") . DIRECTORY_SEPARATOR;
    
            // --- Пытаемся получить список файлов тремя способами ---
            $names = null;
    
            // 1) Основной: fs::scan()
            try {
                $scan = fs::scan($modsDir);
                if (is_array($scan)) {
                    $names = $scan;
                }
            } catch (\Throwable $e) {
                self::safeLog("⚠ cleanModsDirectory: scan(fs::scan) error: " . $e->getMessage());
            }
    
            // 2) Fallback: scandir()
            if (!is_array($names)) {
                try {
                    $scan = @scandir($modsDir);
                    if (is_array($scan)) {
                        $names = array_values(array_filter($scan, function($n) {
                            return $n !== '.' && $n !== '..';
                        }));
                    }
                } catch (\Throwable $e) {
                    self::safeLog("⚠ cleanModsDirectory: scan(scandir) error: " . $e->getMessage());
                }
            }
    
            // 3) Fallback: glob()
            if (!is_array($names)) {
                try {
                    $paths = @glob($modsDir . '*');
                    if (is_array($paths)) {
                        $names = array_map('basename', $paths);
                    }
                } catch (\Throwable $e) {
                    self::safeLog("⚠ cleanModsDirectory: scan(glob) error: " . $e->getMessage());
                }
            }
    
            if (!is_array($names)) {
                self::safeLog("⚠ cleanModsDirectory: не удалось получить список файлов — пропускаю очистку");
                return;
            }
    
            $allow = array_flip($allowList);
            foreach ($names as $name) {
                $path = $modsDir . $name;
                if (fs::isFile($path)) {
                    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                    if ($ext === 'jar' && !isset($allow[$name])) {
                        self::safeLog("🧹 Удаляем лишний мод: $name");
                        @unlink($path);
                    }
                }
            }
        } catch (\Throwable $e) {
            self::safeLog("❌ cleanModsDirectory: " . $e->getMessage());
        }
    }

    /** Кодирование имени файла для URL (пробелы -> %20) */
    public static function encodeFileNameForUrl(string $fileName): string
    {
        return str_replace('%2F', '/', rawurlencode($fileName));
    }
}