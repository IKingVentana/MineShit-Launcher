<?php
namespace app\modules;

use Throwable;
use std, gui, framework, app;
use php\lib\fs;
use php\io\File;
use php\lang\System;

class DownloaderModule extends AbstractModule
{

    /**
     * @event ConfigDownloader.progress 
     */
    function doConfigDownloaderProgress(ScriptEvent $e = null)
    {    
        
    }

    /**
     * Скачивание архива
     */
    static function downloadZip($url, $localPath, $onProgress = null) {
        fs::copy($url, $localPath);
        // Можно добавить onProgress если требуется (в цикле скачивания)
    }

    /**
     * Распаковка архива через PowerShell
     */
    static function extractZip($zip, $dest)
    {
        if (!fs::isFile($zip)) {
            throw new \Exception("Архив не найден: $zip");
        }
        if (!fs::isDir($dest)) {
            fs::makeDir($dest, 0777, true);
        }
    
        // Используем ZipArchive — работает внутри DevelNext!
        $zipArchive = new \ZipArchive();
        if ($zipArchive->open($zip) === true) {
            $zipArchive->extractTo($dest);
            $zipArchive->close();
            fs::delete($zip);
        } else {
            throw new \Exception("Ошибка открытия архива $zip");
        }
    }

    /**
     * Проверка, установлен ли клиент
     */
    static function isInstalled($appdata) {
        return is_dir($appdata . "\\.mineshit\\game")
            && is_file($appdata . "\\.mineshit\\jre\\java-runtime-gamma\\windows-x64\\java-runtime-gamma\\bin\\javaw.exe");
    }
}
