<?php
namespace app\forms;

use std, gui, framework, app;


class Profile extends AbstractForm
{

}