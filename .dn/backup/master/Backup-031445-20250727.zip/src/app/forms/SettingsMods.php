<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\event\UXMouseEvent;

class SettingsMods extends AbstractForm
{
    public $onApply = null;
    public $modCheckboxes = [];

    public $modsList = [
        "DistantHorizon"   => "DistantHorizons-2.3.4-b-1.20.1-fabric-forge.jar",
        "VoiceChat"        => "voicechat-forge-1.20.1-2.5.35.jar",
        "EmojiType"        => "emoji-type-2.2.3+1.20.4-forge legacy.jar",
        "CameraOverhaul"   => "CameraOverhaul-v2.0.4-forge+mc[1.20.0-1.20.5].jar",
        "JEI"              => "jei-1.20.1-forge-15.20.0.108.jar",
        "XaerosWorldMap"   => "[CLIENT] XaerosWorldMap_1.39.9_Forge_1.20.jar",
        "XaerosMinimap"    => "[CLIENT] Xaeros_Minimap_25.2.6_Forge_1.20.jar"
    ];

    public $defaultMods = [
        "DistantHorizon"   => false,
        "VoiceChat"        => true,
        "EmojiType"        => true,
        "CameraOverhaul"   => false,
        "JEI"              => true,
        "XaerosWorldMap"   => true,
        "XaerosMinimap"    => true
    ];

    /**
     * @event form.show
     */
    function doFormShow()
    {
        // Путь к папке и файлу
        $appdata = getenv('APPDATA');
        $gameDir = $appdata . "\\.mineshit\\game";
        $configFile = $gameDir . "\\mods_config.json";
        $modsConfig = $this->defaultMods;

        // Читаем настройки из файла если он есть
        if (file_exists($configFile)) {
            $fileData = json_decode(file_get_contents($configFile), true);
            if (is_array($fileData)) {
                $modsConfig = array_merge($modsConfig, $fileData);
            }
        }

        // Устанавливаем состояния чекбоксов
        foreach ($this->modsList as $modId => $filename) {
            if (isset($this->{$modId})) {
                $this->{$modId}->selected = !!$modsConfig[$modId];
                $this->modCheckboxes[$modId] = $this->{$modId};
            }
        }
    }

    /**
     * @event ApplyModsButton.click-Left
     */
    function doApplyModsButtonClickLeft(UXMouseEvent $e = null)
    {
        $selectedMods = [];
        foreach ($this->modCheckboxes as $modId => $checkbox) {
            $selectedMods[$modId] = $checkbox->selected;
        }
    
        // Получаем путь к конфигу
        $appdata = getenv('APPDATA');
        $gameDir = $appdata . "\\.mineshit\\game";
        $configFile = $gameDir . "\\mods_config.json";
    
        // Убеждаемся, что папка существует
        if (!is_dir($gameDir)) mkdir($gameDir, 0777, true);
    
        // Вот СЮДА и вставь:
        file_put_contents($configFile, json_encode($selectedMods, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
        // Прячем окно настроек
        $this->hide();
    
        // Колбек (если нужен)
        if (is_callable($this->onApply)) {
            call_user_func($this->onApply, $selectedMods);
        }
    }
}