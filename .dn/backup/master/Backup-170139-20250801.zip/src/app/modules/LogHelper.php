<?php
namespace app\modules;

use php\time\Time;
use function file_put_contents;
use const FILE_APPEND;
use function getenv;
use php\lib\fs;

class LogHelper
{
    static function log($msg)
    {
        $logDir = getenv('APPDATA') . '\\.mineshit\\logs\\';
        if (!fs::isDir($logDir)) {
            fs::makeDir($logDir, 0777, true);
        }

        // Имя файла логов — по дате
        $dateForLog = Time::now()->toString('yyyy-MM-dd');
        $logFile = $logDir . 'launcher_' . $dateForLog . '.log';

        // Время для записи в лог
        $timeForLog = Time::now()->toString('yyyy-MM-dd HH:mm:ss');

        $line = "[$timeForLog] $msg\n";
        file_put_contents($logFile, $line, FILE_APPEND);
    }
}