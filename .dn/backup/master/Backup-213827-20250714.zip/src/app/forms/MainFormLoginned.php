<?php
namespace app\forms;

use Exception;
use gui;
use php\gui\UXNode;
use php\gui\framework\AbstractForm;
use php\io\IOException;
use php\lang\ProcessBuilder;
use php\lang\System;
use php\util\Regex;
use php\gui\event\UXWindowEvent;
use php\gui\event\UXMouseEvent;
use app\modules\ControlFinder; // Подключаем модуль

class MainFormLoginned extends AbstractForm
{
    private $modSettingsVisible = false;

    /**
     * @event ModSettingsButton.click-Left
     */
    function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
    {
        $this->modSettingsVisible = !$this->modSettingsVisible;
        $this->ModSettingsFragment->visible = $this->modSettingsVisible;

        if ($this->modSettingsVisible) {
            $this->ModSettingsButton->text = "Принять настройки";
            $this->ModSettingsButton->style = "-fx-background-color: #FFB800;";
        } else {
            $this->ModSettingsButton->text = "Настройки модов";
            $this->ModSettingsButton->style = "-fx-background-color: #FFFFFF;";
            $this->saveModSettings(); // вызываем сохранение
        }
    }

    /**
     * @event LeaveAccountButton.click-Left 
     */
    function doLeaveAccountButtonClickLeft(UXMouseEvent $e = null)
    {
        // Логика выхода из аккаунта
    }

    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть Discord ссылку или другое действие
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть Telegram ссылку или другое действие
    }

    /**
     * @event DonateButton.click-Left 
     */
    function doDonateButtonClickLeft(UXMouseEvent $e = null)
    {
        // Обработка пожертвований
    }

    /**
     * @event FolderButton.click-Left 
     */
    function doFolderButtonClickLeft(UXMouseEvent $e = null)
    {
        // Открыть папку с игрой или другое действие
    }

    /**
     * @event SettingsButton.click-Left 
     */
    function doSettingsButtonClickLeft(UXMouseEvent $e = null)
    {
        $form = app()->getForm('Settings');
        $form->setPreviousForm('MainFormLoginned'); // или 'MainForm' в другом случае
        $form->show();
        $this->hide();
    }

    /**
     * Установить ник игрока в поле логина
     */
    function setPlayerName(string $login)
    {
        if (isset($this->LauncherLoginField)) {
            $this->LauncherLoginField->text = $login;
            $this->LauncherLoginField->editable = false;
        }
    }
}