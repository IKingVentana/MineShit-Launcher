<?php
namespace app\forms;

use std, gui, framework, app;


class Update extends AbstractForm
{

}
