<?php
namespace app\forms;

use std, gui, framework, app;


class NoUpdate extends AbstractForm
{

}
