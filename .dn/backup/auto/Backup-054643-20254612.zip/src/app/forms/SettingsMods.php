<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\event\UXMouseEvent;
use php\gui\UXCheckbox;
use php\gui\UXForm;

class SettingsMods extends AbstractForm
{
    public $onApply = null;

    /**
     * @event form.show
     */
    function doFormShow()
    {
        // Начальные значения можно загрузить из файла или оставить как есть
    }

    /**
     * @event ApplyModsButton.click-Left
     */
    function doApplyModsButtonClickLeft(UXMouseEvent $e = null)
    {
        // Пример сохранения выбранных модов
        $selectedMods = [];

        if ($this->CreateCheckbox->selected) {
            $selectedMods[] = "create";
        }

        if ($this->JEICheckbox->selected) {
            $selectedMods[] = "jei";
        }

        if ($this->SupplementariesCheckbox->selected) {
            $selectedMods[] = "supplementaries";
        }

        // Здесь можно обработать зависимости
        if (in_array("supplementaries", $selectedMods) && !in_array("create", $selectedMods)) {
            UXDialog::show("⚠ Мод Supplementaries требует Create. Добавляем автоматически.");
            $selectedMods[] = "create";
            $this->CreateCheckbox->selected = true;
        }

        // Сохраняем в файл
        file_put_contents("mods_config.json", json_encode($selectedMods, JSON_PRETTY_PRINT));

        // Возврат к основной форме (или скрытие этого окна)
        $this->hide();

        if (is_callable($this->onApply)) {
            call_user_func($this->onApply, $selectedMods);
        }
    }
    
    
    
    
    
    
}
