<?php
namespace app\forms;

use std;
use gui;
use php\gui\framework\AbstractForm;
private $modSettingsVisible = false;
use php\io\IOException;
use php\lang\ProcessBuilder;
use php\lang\System;
use php\util\Regex;

class MainFormLoginned extends AbstractForm
{

/**
 * @event ModSettingsButton.click-Left
 */
function doModSettingsButtonClickLeft(UXMouseEvent $e = null)
{
    $this->modSettingsVisible = !$this->modSettingsVisible;
    $this->ModSettingsFragment->visible = $this->modSettingsVisible;

    if ($this->modSettingsVisible) {
        $this->ModSettingsButton->text = "Принять настройки";
        $this->ModSettingsButton->style = "-fx-background-color: #FFB800;";
    } else {
        $this->ModSettingsButton->text = "Настройки модов";
        $this->ModSettingsButton->style = "-fx-background-color: #FFFFFF;";
        $this->saveModSettings(); // вызываем сохранение
    }
}


    /**
     * @event LeaveAccountButton.click-Left 
     */
    function doLeaveAccountButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event DiscordButton.click-Left 
     */
    function doDiscordButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event TelegramButton.click-Left 
     */
    function doTelegramButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event DonateButton.click-Left 
     */
    function doDonateButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event StartButton.click-Left 
     */
    function doStartButtonClickLeft($e) {
        global $form;
    
        // Путь к папке лаунчера
        $launcherDir = System::getProperty("user.dir"); // Текущий путь
        $mcDir = "$launcherDir\\minecraft";
        $javaPath = "$launcherDir\\java\\bin\\javaw.exe";
        
        // Никнейм
        $username = trim($form->LauncherLoginField->text);
        if ($username == "") {
            ui\UXDialog::show("Введите никнейм!", "ERROR");
            return;
        }
    
        // UUID offline (пока просто статичный)
        $uuid = "00000000-0000-0000-0000-000000000000";
        
        // Версия Forge
        $version = "forge-1.20.1-47.4.0";
        $versionDir = "$mcDir\\versions\\$version";
        $forgeJar = "$versionDir\\$version.jar";
    
        // Выбранный объем RAM
        $ramOption = $form->RamSelect->selectedText; // например: "4"
        $xmx = "Xmx" . $ramOption . "G";
        $xms = "Xms" . min(2, intval($ramOption)) . "G"; // минимум Xms2G
    
        // Java args
        $args = [
            $javaPath,
            "-$xmx",
            "-$xms",
            "-Djava.library.path=$mcDir\\natives",
            "-cp", buildClasspath($mcDir, $version, $forgeJar),
            "net.minecraft.launchwrapper.Launch",
            "--username", $username,
            "--uuid", $uuid,
            "--accessToken", "0",
            "--userType", "mojang",
            "--version", $version,
            "--gameDir", $mcDir,
            "--assetsDir", "$mcDir\\assets",
            "--assetIndex", "1.20",
            "--versionType", "release"
        ];
    
        // Запуск процесса
        try {
            $builder = new ProcessBuilder($args);
            $builder->directory(new File($launcherDir));
            $process = $builder->start();
        } catch (IOException $ex) {
            ui\UXDialog::show("Ошибка запуска Minecraft:\n" . $ex->getMessage(), "ERROR");
        }
    }


    function setPlayerName(string $login)
    {
        if (isset($this->LauncherLoginField)) {
            $this->LauncherLoginField->text = $login;
            // Опционально: сделай поле только для чтения
            $this->LauncherLoginField->editable = false;
        }
    }










}
