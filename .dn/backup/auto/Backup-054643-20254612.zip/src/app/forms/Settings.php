<?php
namespace app\forms;

use std, gui, framework, app;


class Settings extends AbstractForm
{

    /**
     * @event ExitButton.click-Left 
     */
    function doExitButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    function setRam($ramValue) {
        global $form, $selectedRam;
        $selectedRam = $ramValue;
    
        $buttons = [
            3 => $form->RamButton3,
            4 => $form->RamButton4,
            6 => $form->RamButton6,
            8 => $form->RamButton8,
            10 => $form->RamButton10
        ];
    
        foreach ($buttons as $value => $button) {
            if ($value == $ramValue) {
                $button->style = "-fx-background-color: #FFB800; -fx-background-radius: 8px; -fx-text-fill: black;";
            } else {
                $button->style = "-fx-background-color: #2C2C2C; -fx-background-radius: 8px; -fx-text-fill: white;";
            }
        }
    }
    
    // Вызов при нажатии кнопок:
    function doRamButton3Click(...) { setRam(3); }
    function doRamButton4Click(...) { setRam(4); }
    function doRamButton6Click(...) { setRam(6); }
    function doRamButton8Click(...) { setRam(8); }
    function doRamButton10Click(...) { setRam(10); }



}
